import json
import boto3
import markdown
import os
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Log toàn bộ event để kiểm tra
    print(json.dumps(event))
    
    # Lấy body của SQS message (chứa SNS notification)
    for record in event['Records']:
        sns_message = json.loads(record['body'])
        s3_event = json.loads(sns_message['Message'])
        
        # Trích xuất thông tin bucket và object từ S3 event
        bucket_name = s3_event['Records'][0]['s3']['bucket']['name']
        object_key = s3_event['Records'][0]['s3']['object']['key']
        
        # Tải file markdown từ S3
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        markdown_content = response['Body'].read().decode('utf-8')
        
        # Convert markdown to HTML
        html_content = markdown.markdown(markdown_content)
        
        # Lưu HTML vào S3 (có thể sử dụng một bucket khác để làm static web hosting)
        html_key = object_key.replace(".md", ".html")
        output_bucket = os.environ['OUTPUT_BUCKET']  # Thay bằng bucket chứa file HTML
        s3_client.put_object(Bucket=output_bucket, Key=html_key, Body=html_content, ContentType='text/html')
        
        return {
            'statusCode': 200,
            'body': json.dumps(f"File {object_key} đã được convert và lưu vào {output_bucket}/{html_key}")
        }

